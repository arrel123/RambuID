package com.example.rambuid

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
